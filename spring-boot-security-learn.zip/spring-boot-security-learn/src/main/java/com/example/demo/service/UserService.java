package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.model.User;

@Service
public class UserService {

	List<User> list = new ArrayList<>();

	public UserService(List<User> list) {
		list.add(new User("Sayali Sawant", "Sayali@24", "sayalisawant798@gmail.com"));
		list.add(new User("abc", "abc", "abc@gmail.com"));

		this.list = list;
	}

	public List<User> getAllUsers() {
		return this.list;
	}

	public User getUser(String userName) {
		return this.list.stream().filter(user -> user.getUserName().equals(userName)).findAny().orElse(null);
	}

	public User addUser(User user) {
		this.list.add(user);
		return user;
	}
}
