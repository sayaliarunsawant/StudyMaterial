package String;

import java.util.stream.Stream;

public class DuplicateCountDemo {

	public static void main(String[] args) {

		int count = 0;

		String str = "This is the DuplicateCountDemo Class";

		String[] strArray = str.split("");
		
		Stream.of(strArray).distinct().forEach(System.out::println);

		for (int i = 0; i < strArray.length; i++) {

			for (int j = 1; j < strArray.length; j++) {

				if (strArray[i] == strArray[j])
					System.out.println(strArray[i]+ " "+strArray[j]);
			}
			
			
		}
		
		

	}

}
