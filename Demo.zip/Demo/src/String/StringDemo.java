package String;

public class StringDemo {
	public static void main(String[] args) {
		String s1 = new String("Sayali");
		String s2 = new String("Sayali");
		
		String s3 ="abc";
		String s4 =new String("abc");
		
		System.out.println(s3.equals(s4));
		System.out.println(s3==s4);
		
		System.out.println(s1.equals(s2)+" ");
		System.out.println(s1==s2);
		
		StringBuffer sb1 = new StringBuffer("Komal");
		StringBuffer sb2 = new StringBuffer("Komal");
		
		System.out.println(sb1.equals(sb2)+" ");
		System.out.println(sb1==sb2);
		
		StringBuilder sb3 = new StringBuilder("Prajakta");
		StringBuilder sb4 = new StringBuilder("Prajakta");
		
		System.out.println(sb3.equals(sb4)+" ");
		System.out.println(sb3==sb4);
		
		
		
	}
}
