package String;

import java.util.StringJoiner;  
public class ExampleofStringJoiner
{  
   public static void main(String[] args) 
   {  
       StringJoiner joinStrings = new StringJoiner(",", "[", "]");
       // passing comma(,) and square-brackets as delimiter   
         
       // Adding values to StringJoiner  
       joinStrings.add("Scaler");  
       joinStrings.add("By");  
       joinStrings.add("InterviewBit");            
       System.out.println(joinStrings);  
       
       String str1 = "scaler";                          //Line1
       String str2 = new String("scaler");      //Line2
       str2.intern();                                       //Line 3
       System.out.println(str1 == str2);
   }  
}
