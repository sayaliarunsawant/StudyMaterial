package String;

import java.util.Scanner;

public class ReverseStringDemo {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str;

		System.out.println("Enter string for reverse : ");
		str = sc.nextLine();

		String reverse = reverse(str);

		System.out.println("Reverse of " + str + " is " + reverse);
		sc.close();
	}

	private static String reverse(String str) {

		String rev = "";
		for (int i = str.length() - 1; i >= 0; i--) {
			rev = rev + str.charAt(i);
		}
		return rev;
	}
}
