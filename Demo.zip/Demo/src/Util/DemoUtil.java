package Util;

import java.util.ArrayList;
import java.util.List;

import Object.Employee;

public class DemoUtil {

	public static List<Employee> getEmployee() {
		
		Employee emp1 = new Employee(1, "Sayali", 50000);
		Employee emp2 = new Employee(2, "Prajakta", 60000);
		Employee emp3 = new Employee(3, "Komal", 70000);
		Employee emp4 = new Employee(4, "Kanchan", 80000);
		
		
		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(emp1);
		employeeList.add(emp2);
		employeeList.add(emp3);
		employeeList.add(emp4);
		
		return employeeList;
		
		
	}
}
