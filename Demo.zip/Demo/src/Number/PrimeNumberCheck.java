package Number;

import java.util.Scanner;

public class PrimeNumberCheck {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Number : ");

		int number = sc.nextInt();
		boolean result = checkIsPrime(number);

		if (result) {
			System.out.println(number + " is prime");
		}

		sc.close();
	}

	private static boolean checkIsPrime(int n) {
		if (n == 0 || n == 1) {
			return false;
		}
		if (n == 2) {
			return true;
		}
		for (int i = 2; i <= n / 2; i++) {
			if (n % i == 0) {
				return false;
			}
		}
		return true;
	}
}
