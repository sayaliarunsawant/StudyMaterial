package Stream;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

//How to check if list is empty in Java 8 using Optional, if not null iterate through the list and print the object?

public class OptionalDemo {

	public static void main(String[] args) {

		Integer a[] = new Integer[] { 10, 20, 30, 40 };

		// Getting the list view of Array
		List<Integer> list = Arrays.asList(a);

		Optional.ofNullable(list);

		Stream<Integer> stream = list.stream();
		Integer[] result = stream.filter(n -> n % 2 == 0).toArray(Integer[]::new);
		System.out.println(result);
	}
}
