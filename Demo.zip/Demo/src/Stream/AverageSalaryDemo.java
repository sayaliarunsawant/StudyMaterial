package Stream;

import Object.Employee;
import Util.DemoUtil;

public class AverageSalaryDemo {
	
	public static void main(String[] args) {
		System.out.println(DemoUtil.getEmployee().stream().mapToDouble(Employee::getSalary).average().getAsDouble()) 	;
	}

}
