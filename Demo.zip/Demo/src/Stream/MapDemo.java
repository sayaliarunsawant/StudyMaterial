package Stream;

import java.util.Arrays;
import java.util.List;

//How to use map to convert object into Uppercase in Java 8

public class MapDemo {


	
	public static void main(String[] args) {
		List<String> names = Arrays.asList("aa", "bb", "cc", "dd");
		names.stream().map(nm->nm.toUpperCase()).forEach(System.out::println);
	}
}
