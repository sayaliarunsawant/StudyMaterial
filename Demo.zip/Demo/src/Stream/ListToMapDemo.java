package Stream;

import java.util.Map;
import java.util.stream.Collectors;

import Object.Employee;
import Util.DemoUtil;

//How to convert a list of objects to a Map in Java 8 by handling duplicate keys?
public class ListToMapDemo {

	public static void main(String[] args) {
		Map<String, Integer> EmployeeRecords = DemoUtil.getEmployee().stream()
				.collect(Collectors.toMap(Employee::getName, Employee::getEmpId, (oldValue, newValue) -> oldValue));

		System.out.println("Employes : " + EmployeeRecords);

		for (Map.Entry<String, Integer> map : EmployeeRecords.entrySet()) {
			System.out.println(map.getKey() + " : " + map.getValue());
		}
	}
}
