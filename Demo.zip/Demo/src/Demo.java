import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

public class Demo {

	// Create a program to arrange your neighborhood in ascending order Sample
	// {{2,6,4},{7,4,8},{9,0,1}} Output{{0,1,2},{4,6,8},{4,7,9}}
	// {{2 ,7,9},{0,4,6},{1,4,8}

	public static void main(String[] args) {

		Integer[][] a = new Integer[][] { { 2, 6, 4 }, { 7, 4, 8 }, { 9, 0, 1 } };

		for (int i = 0; i < a.length; i++) {

			Integer[] temp = a[i];

			for (int j = 0; j < temp.length; j++) {
				for (int k = 1; k < temp.length; k++) {
					if (a[i] == a[j]) {

					}
				}
			}
		}

//		Stream<String> stream = Stream.of("Sayali", "java");
//		stream.filter(s->s.matches())
		
		


			                        List list = Arrays.asList(4,6,12,66,3);

			  

			                          String  s = list.stream().map( i -> {

			                                   return ""+(i+1);

			                          }).reduce("",String::concat);
			  

			                         System.out.println(s);
		

	}
	
	public static List<Integer> findDuplicates(int[] nums) {
	    Set<Integer> set = new HashSet<>();
	    return Arrays.stream(nums)
	                 .filter(n -> !set.add(n)) 
	                 .distinct()
	                 .boxed().toList();
	}
	
	
//	public static String sort(String input) {
//	    
//	    
//	    Map<Character, Integer> f= new HashMap<>();
//	    for (char char : input.toCharArray()) {
//	        f.put(char, frequency.getOrDefault(char, 0) + 1);
//	    }
//	    
//	    
//	    List<Character> sortedChars = new ArrayList<>(frequency.keySet());
//	    sortedChars.sort((c1, c2) -> f.get(c1) - f.get(c2));
//	    
//	  
//	    String s = new String();
//	    for (char c : sortedChars) {
//	        int count = frequency.get(c);
//	        for (int i = 0; i < count; i++) {
//	            s.append(c);
//	        }
//	    }
//	    return s;
//	}
}