import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

class Car {
	public void acc() {
		System.out.println("Geep");
	}
}

public class Test extends Car {

	public static void main(String[] args) {
		
	
	List<Boolean> list = new ArrayList<>();
	list.add(true);
	list.add(Boolean.parseBoolean("FalSe"));
	list.add(Boolean.TRUE);
	System.out.println(list.size());
	System.out.println(list.get(1)instanceof Boolean);
	
	
	Queue<Integer> q = new PriorityQueue<>();
	q.add(4);
	q.add(3);
	q.add(2);
	q.add(1);
	
	while (q.isEmpty()==false) {
		System.out.println("%d"+q.remove());
	}
	
		String s ="420";
		
		System.out.println(s.length());
	
		
	}
	
	static void print(int i) throws Exception
	{
		if(i>0)
		{
			throw new ArithmeticException();
		}else
		{
			throw new Exception();
		}
	}
	
}
