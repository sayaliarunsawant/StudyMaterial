package Collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HashMapDemo {

	public static void main(String[] args) {
		Map<String, Integer> marks = new HashMap<String, Integer>();
		marks.put("Naveen", 100);
		marks.put("Tom", 200);
		marks.put("Lisa", 300);
		marks.put("Peter", 400);
		marks.put("Robby", 600);
		marks.put(null, 500);

		System.out.println(marks);
		
		
		marks.forEach((k,v)->{
			System.out.println("Key : "+k+"  Value : "+v);
		});

		
		for (Map.Entry<String, Integer> m : marks.entrySet()) {
			
			System.out.println("Key :: "+m.getKey()+"  Value::"+m.getValue());
		}
	}

}
