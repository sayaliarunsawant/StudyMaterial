package Collection;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;

public class ComparableDemo {

	public static void main(String[] args) {

		ArrayList<Employee> list = new ArrayList<Employee>();

		list.add(new Employee(22l, "Lokesh", LocalDate.now()));
		list.add(new Employee(18l, "Alex", LocalDate.now()));
		list.add(new Employee(30l, "Bob", LocalDate.now()));
		list.add(new Employee(600l, "Charles", LocalDate.now()));
		list.add(new Employee(5l, "David", LocalDate.now()));

		System.out.println(list);

		Collections.sort(list, Collections.reverseOrder());

		System.out.println(list);
	}

}
